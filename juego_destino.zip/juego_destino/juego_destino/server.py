from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Aquí se procesarían los datos del formulario y se haría la predicción
    destino = request.form.get('destino')  # Ejemplo de obtención de datos
    # Lógica para predecir el destino
    return render_template('futuro.html', destino=destino)

if __name__ == '__main__':
    app.run(debug=True)