# Proyecto Juego Destino

Este proyecto es una aplicación web desarrollada con Flask que permite a los usuarios ingresar datos para predecir un destino. La aplicación consta de un formulario donde los usuarios pueden introducir información, y una página que muestra la predicción basada en esos datos.

## Estructura del Proyecto

```
juego_destino
├── server.py          # Punto de entrada de la aplicación Flask
├── templates          # Carpeta que contiene las plantillas HTML
│   ├── index.html     # Plantilla para mostrar el formulario
│   └── futuro.html    # Plantilla para mostrar la predicción del destino
├── static             # Carpeta que contiene archivos estáticos
│   └── style.css      # Hoja de estilos CSS para mejorar la presentación
└── README.md          # Documentación del proyecto
```

## Requisitos

- Python 3.x
- Flask

## Instalación

1. Clona este repositorio en tu máquina local.
2. Navega a la carpeta del proyecto.
3. Instala las dependencias necesarias ejecutando:

```
pip install Flask
```

## Ejecución

Para ejecutar la aplicación, utiliza el siguiente comando:

```
python server.py
```

La aplicación estará disponible en `http://127.0.0.1:5000/`.

## Contribuciones

Las contribuciones son bienvenidas. Si deseas mejorar este proyecto, por favor abre un issue o envía un pull request.

## Licencia

Este proyecto está bajo la Licencia MIT.