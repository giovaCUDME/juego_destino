import random

def predecir_destino(nombre, fecha_nacimiento):
    destinos = [
        "Tendrás un día lleno de sorpresas.",
        "El éxito está cerca, sigue adelante.",
        "Hoy es buen momento para tomar decisiones importantes.",
        "Alguien especial aparecerá en tu vida.",
        "Recibirás buenas noticias pronto.",
        "Tu esfuerzo será recompensado.",
        "La suerte te acompañará en tus proyectos."
    ]
    random.seed(hash(nombre + fecha_nacimiento))
    return random.choice(destinos)
